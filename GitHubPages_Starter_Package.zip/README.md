# JZN Live Platform

This repository hosts the JZN Live Platform for GitHub Pages.

- Deploy from the `main` branch, root folder.
- Open https://USERNAME.github.io/REPO/ after enabling Pages.
