
# JZN Live Platform — GitHub Pages Deployment

This package contains the correct files required to deploy your v2 platform on GitHub Pages.

## Files Included
- `index.html` — Your full v2 platform (rename of `index_full_v2 (1).html`)
- `.nojekyll` — Prevents Jekyll from interfering with your HTML
- `README.md` — Deployment guide

## Deployment Steps
1. Upload all files to your GitHub repository `halloos-live` into the root of the `main` branch.
2. Go to **Settings → Pages**.
3. Set **Source = Deploy from a branch**.
4. Select **main** and **root (/)**.
5. Your final site URL will be:
   https://halloosMedia.github.io/halloos-live/
